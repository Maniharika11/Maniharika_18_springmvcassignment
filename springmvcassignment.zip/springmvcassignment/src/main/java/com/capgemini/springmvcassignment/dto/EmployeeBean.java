package com.capgemini.springmvcassignment.dto;

import java.io.Serializable;

import lombok.Data;
@Data
public class EmployeeBean implements Serializable {
	int empId;
	String empName;
	int age;
	double salary;
	String designation;
	String password;

}
